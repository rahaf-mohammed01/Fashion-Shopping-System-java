package actors;

public class Employee extends Person {
    private int employeeId;
    public String department;
    protected boolean onShift;
    private double salary;

    public Employee(String name, String email, int age, int employeeId, String department, boolean onShift,
                    double salary) {
        super(name, email, age);
        this.employeeId = employeeId;
        this.department = department;
        this.onShift = onShift;
        this.salary = salary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        if (employeeId >= 0) {
            this.employeeId = employeeId;
        } else {
            System.out.println("Invalid employee ID.");
        }
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public boolean isOnShift() {
        return onShift;
    }

    public void setShiftStatus(boolean onShift) {
        this.onShift = onShift;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        if (salary >= 0) {
            this.salary = salary;
        } else {
            System.out.println("Invalid base salary.");
        }
    }

    public double TotalSalary() {
        return salary;
    }

    public void checkShiftStatus() {
        if (isOnShift()) {
            System.out.println("Employee " + getName() + " in department " + getDepartment() +
                    " is on a shift.");
        } else {
            System.out.println("Employee " + getName() + " in department " + getDepartment() +
                    " is not on a shift.");
        }
    }
   
}
