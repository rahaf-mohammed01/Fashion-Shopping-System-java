package actors;

public class Customer extends Person {
    private int customerNumber;

    public Customer(String name, String email, int age, int customerNumber) {
        super(name, email, age);
        this.customerNumber = customerNumber;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }

    public void order(int orderNum) {
        System.out.println("Customer has an order: " + orderNum);
    }
}
