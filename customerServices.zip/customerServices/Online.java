package customerServices;

import items.Product;

public class Online extends Order {
    public Online(Product productName, int quantity, Shipping shipping) {
        super(productName, quantity, shipping);
    }

    @Override
    public double TotalCost() {
        return productName.getPrice() * quantity;
    }

    public void shipProduct() {
        shippingMethod.shipProduct();
    }
}
