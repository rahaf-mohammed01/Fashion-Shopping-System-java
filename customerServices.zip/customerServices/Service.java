package customerServices;


public class Service {
    public String serviceName;

    public Service(String serviceName, String department) {
        this.serviceName = serviceName;
        
    }

    public void performDuties() {
        System.out.println("Performing service duties.");
    }

    public void handleCustomerInquiries() {
        System.out.println("Handling customer inquiries.");
    }

    public String getServiceName() {
        return serviceName;
    }
}
