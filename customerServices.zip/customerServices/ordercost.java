package customerServices;

public interface ordercost {
    double TotalCost();
}
