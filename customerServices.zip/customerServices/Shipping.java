package customerServices;

public interface Shipping {
    void deliverProduct();
    void shipProduct();
}
